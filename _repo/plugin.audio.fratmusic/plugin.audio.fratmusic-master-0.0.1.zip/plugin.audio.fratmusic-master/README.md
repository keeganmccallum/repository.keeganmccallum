plugin.audio.fratmusic
======================

xbmc plugin for fratmusic website
